XUI Windows Bundle
==================

1) Install Python 3.10+ (Add to PATH).
2) Run install_xui_windows.bat (in this folder).
3) After installation, launch %USERPROFILE%\.xui\bin\xui_start.bat
